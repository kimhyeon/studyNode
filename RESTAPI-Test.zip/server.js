const express = require('express');
const path = require('path');
const methodOverride = require('method-override');
const bodyParser = require('body-parser');

const db = require('./db');
const router = require('./route.js');
const app = express();

db();

app.use(express.static(path.join(__dirname, 'public')));

app.use(methodOverride()); // put delete 지원안하는 브라우저 처리
app.use(bodyParser.json()); // body 의 데이터를 json 형식으로 받음
app.use(bodyParser.urlencoded({ extended: true })); // ? qs모듈로 쿼리스트링 파싱

app.use("/", router);

app.use((err, req, res, next) => {
	console.log(err.stack);
	res.status(500).send('서버 에러!');
});

app.listen(8084, () => {
  console.log('Express App on port 8084!');
});