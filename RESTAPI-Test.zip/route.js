const express = require('express');
const path = require('path');

const router = express.Router();

const User = require('./user.js'); // mongo collection users ...

router.get('/', (req, res) => {
	res.sendFile(path.join(__dirname, 'apiTest.html'));
});

// router.get('/user', (req, res) => {
// 	console.log("[get] user router");
// 	console.log(req.body);
// });

router.post('/user', (req, res, next) => {
	let reqBodyStr = JSON.stringify(req.body)
	console.log("HTTP POST /user", ","+reqBodyStr);

	var temp = new User();
	temp.name = req.body.name;
	temp.data = req.body.data;

	temp.save((err, result) => {
		if (err) {
			console.error(err);
			res.status(500).json(err);
			return next(err);
		} 
		res.status(200).json(result);
	});

});

router.delete('/user/:name', (req, res) => {
	let reqBodyStr = JSON.stringify(req.body)
	console.log("HTTP DELETE /user/:name", ","+reqBodyStr);

	let tName = req.body.name;

	User.remove({name: tName}, (err, result) => {
		if (err) {
			console.error(err);
			res.status(500).json(err);
			return next(err);
		}

		res.status(200).json(result);
	});

});

router.get('/user/:name', (req, res) => {
	let reqBodyStr = JSON.stringify(req.body)
	console.log("HTTP GET /user/:name", ","+reqBodyStr);

	let tName = req.params.name;

	User.find({name : tName}, (err, result) => {
		if (err) {
			console.error(err);
			return next(err);
		}
		console.log("result:", result);
		//res.json(result);
		res.status(200).send(result);
	});
});

// PUT은 전체 수정, PATCH는 부분 수정,

router.patch('/change/:name/name/:new', (req, res) => {
	let reqBodyStr = JSON.stringify(req.body)
	console.log("HTTP PATCH /change/:name/name/:new", ","+reqBodyStr);

	let reqParams = req.params;
	console.log(reqParams);

	User.update( {
		name: reqParams.name,
	},
	{
		name: reqParams.new,
	},
	(err, result) => {
		if (err) {
			console.error(err);
			return next(err);
		}
		console.log("result:", result);
		res.status(200).send(result);
	});
})

router.get('/userList', (req, res) => {
	console.log("HTTP GET /userList");
	User.find({}, (err, result) => {
		if (err) {
			console.error(err);
			return next(err);
		} 
		console.log("result size:", result.length);
		res.status(200).send(result);
	});
});

module.exports = router;